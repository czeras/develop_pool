//
//  AppConfig.h
//  001---直播架构搭建
//
//  Created by gao feng on 16/7/22.
//  Copyright © 2016年 music4kid. All rights reserved.
//

#ifndef AppConfig_h
#define AppConfig_h


#endif /* AppConfig_h */
