//
//  DBConst.h
//  001---直播架构搭建
//
//  Created by gao feng on 16/7/22.
//  Copyright © 2016年 music4kid. All rights reserved.
//

#ifndef DBConst_h
#define DBConst_h


//table event
#define Event_RowInsert @"Event_RowInsert"
#define Event_RowDelete @"Event_RowDelete"
#define Event_RowUpdate @"Event_RowUpdate"

#define Table_ChannelMessage        @"Table_ChannelMessage"

#endif /* DBConst_h */
