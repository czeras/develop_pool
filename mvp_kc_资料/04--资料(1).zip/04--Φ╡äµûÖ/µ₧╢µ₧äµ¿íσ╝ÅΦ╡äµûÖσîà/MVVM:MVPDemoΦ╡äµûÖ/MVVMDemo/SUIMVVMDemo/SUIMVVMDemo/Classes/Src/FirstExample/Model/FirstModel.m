//
//  FirstModel.m
//  XTMultipleTables
//
//  Created by momo on 15/12/5.
//  Copyright © 2015年 teason. All rights reserved.
//

#import "FirstModel.h"

@implementation FirstModel


@end
