//
//  SMKConstant.h
//  SUIMVVMDemo
//
//  Created by yuantao on 16/2/29.
//  Copyright © 2016年 lovemo. All rights reserved.
//

#ifndef SMKConstant_h
#define SMKConstant_h

// 过期提醒
#define SMKDeprecated(instead) NS_DEPRECATED(2_0, 2_0, 2_0, 2_0, instead)

#endif /* SMKConstant_h */
