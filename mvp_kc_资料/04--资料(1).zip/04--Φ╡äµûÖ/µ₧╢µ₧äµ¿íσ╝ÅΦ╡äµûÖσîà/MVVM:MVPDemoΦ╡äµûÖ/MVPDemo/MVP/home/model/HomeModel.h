//
//  HomeModel.h
//  MVP
//
//  Created by baoshan on 17/2/8.
//  Copyright © 2017年 hans. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeModel : NSObject

@property (nonatomic,assign)NSInteger count;
@property (nonatomic,assign)NSInteger start;
@property (nonatomic,assign)NSInteger total;
@property (nonatomic,assign)NSArray *books;
@end
