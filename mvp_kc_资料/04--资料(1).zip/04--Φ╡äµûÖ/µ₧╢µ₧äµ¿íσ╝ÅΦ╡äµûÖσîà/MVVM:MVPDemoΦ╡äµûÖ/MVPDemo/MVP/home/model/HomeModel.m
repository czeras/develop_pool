//
//  HomeModel.m
//  MVP
//
//  Created by baoshan on 17/2/8.
//  Copyright © 2017年 hans. All rights reserved.
//

#import "HomeModel.h"

@implementation HomeModel

@end
