//
//  HomeBannerModel.m
//  MVP
//
//  Created by hans on 2017/10/9.
//  Copyright © 2017年 hans. All rights reserved.
//

#import "HomeBannerModel.h"

@implementation HomeBannerModel

@end
