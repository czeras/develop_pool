//
//  HomeBannerModel.h
//  MVP
//
//  Created by hans on 2017/10/9.
//  Copyright © 2017年 hans. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeBannerModel : NSObject

@property (nonatomic,copy) NSString *bannerUrl;

@property (nonatomic,copy) NSString *bannerName;
@end
