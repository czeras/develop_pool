# MVP-iOS
简单的封装了一下MVP，希望大伙有更好地想法的可以提出来一起交流。
思路全部写在这里了，http://www.jianshu.com/p/abea207c23e7#
