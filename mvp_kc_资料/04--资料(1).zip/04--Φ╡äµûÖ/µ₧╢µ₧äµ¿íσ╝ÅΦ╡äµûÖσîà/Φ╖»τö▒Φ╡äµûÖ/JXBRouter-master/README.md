# JXBRouter
iOS路由，通过route-controller关联映射进行控制器跳转，支持Controller回调操作


使用方法，具体见http://www.jianshu.com/p/2212c4637055
