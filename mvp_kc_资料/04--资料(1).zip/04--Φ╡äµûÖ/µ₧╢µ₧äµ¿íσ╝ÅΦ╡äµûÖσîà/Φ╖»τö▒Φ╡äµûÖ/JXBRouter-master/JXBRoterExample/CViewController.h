//
//  CViewController.h
//  JXBRoterExample
//
//  Created by 金修博 on 2017/7/24.
//  Copyright © 2017年 huber. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXBRouter.h"

@interface CViewController : UIViewController<JXBRouterProtocol>

@end
