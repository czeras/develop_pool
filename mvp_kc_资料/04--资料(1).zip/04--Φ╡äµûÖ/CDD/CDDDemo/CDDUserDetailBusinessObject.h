//
//  CDDUserDetailBusinessObject.h
//  CDDDemo
//
//  Created by gao feng on 16/2/16.
//  Copyright © 2016年 gao feng. All rights reserved.
//

#import "CDDContext.h"
#import "CDDUserDetailBusinessObjectProtocol.h"

@interface CDDUserDetailBusinessObject : CDDBusinessObject <CDDUserDetailBusinessObjectProtocol>


@end
