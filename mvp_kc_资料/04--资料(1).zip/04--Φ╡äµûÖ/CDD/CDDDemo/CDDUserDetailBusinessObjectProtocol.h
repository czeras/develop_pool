//
//  CDDUserDetailBusinessObjectProtocol.h
//  CDDDemo
//
//  Created by gao feng on 16/2/18.
//  Copyright © 2016年 gao feng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CDDUserDetailBusinessObjectProtocol <NSObject>

- (void)changeUserName:(NSString*)name;

@end
