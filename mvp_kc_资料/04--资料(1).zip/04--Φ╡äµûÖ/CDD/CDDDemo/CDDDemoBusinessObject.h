//
//  CDDDemoBusinessObject.h
//  CDDDemo
//
//  Created by gao feng on 16/2/4.
//  Copyright © 2016年 gao feng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CDDDemoBusinessObjectProtocol.h"
#import "CDDContext.h"

@interface CDDDemoBusinessObject : CDDBusinessObject<CDDDemoBusinessObjectProtocol>

@end
