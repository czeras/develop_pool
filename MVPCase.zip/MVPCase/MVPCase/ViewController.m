//
//  ViewController.m
//  MVPCase
//
//  Created by YongQin on 2021/12/15.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
