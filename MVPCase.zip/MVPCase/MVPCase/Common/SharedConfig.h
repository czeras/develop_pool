//
//  SharedConfig.h
//  001---直播架构搭建
//
//  Created by cooci on 2018/10/23.
//  Copyright © 2018 cooci. All rights reserved.
//

#ifndef SharedConfig_h
#define SharedConfig_h

#define _OwnerID        1000

#endif /* SharedConfig_h */
