//
//  AppDelegate.h
//  MVPCase
//
//  Created by YongQin on 2021/12/15.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

